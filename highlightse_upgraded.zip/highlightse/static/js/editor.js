let saveTimeout;

document.addEventListener('DOMContentLoaded', () => {
    const editor = document.getElementById('document-editor');
    const titleInput = document.getElementById('doc-title-input');
    const indicator = document.getElementById('save-indicator');
    const saveText = document.getElementById('save-text');
    const btnHighlight = document.getElementById('btn-highlight');
    const btnClear = document.getElementById('btn-clear-highlight');
    const searchInput = document.getElementById('doc-search');
    const newDocBtn = document.getElementById('new-doc-btn');

    // Переключение вкладок (Библиотека / Кабинет учителя)
    const tabBtns = document.querySelectorAll('.tab-btn');
    const sections = document.querySelectorAll('.view-section');

    function switchTab(targetId) {
        tabBtns.forEach(b => b.classList.toggle('active', b.dataset.target === targetId));
        sections.forEach(s => s.classList.toggle('active', s.id === targetId));
    }

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => switchTab(btn.dataset.target));
    });

    if (window.location.hash === '#teacher') {
        switchTab('teacher-view');
    }

    // 🖍️ Выделение выбранного текста мягким жёлтым маркером
    if (btnHighlight) {
        btnHighlight.addEventListener('click', () => {
            const selection = window.getSelection();
            if (!selection.rangeCount || selection.isCollapsed) return;

            const range = selection.getRangeAt(0);
            if (!editor.contains(range.commonAncestorContainer)) return;

            const span = document.createElement('span');
            span.className = 'highlight-pen';
            span.appendChild(range.extractContents());
            range.insertNode(span);
            selection.removeAllRanges();

            triggerAutoSave();
        });
    }

    // Очистка маркера внутри редактора
    if (btnClear) {
        btnClear.addEventListener('click', () => {
            const highlights = editor.querySelectorAll('.highlight-pen');
            highlights.forEach(span => {
                const textNode = document.createTextNode(span.textContent);
                span.parentNode.replaceChild(textNode, span);
            });
            triggerAutoSave();
        });
    }

    // 💾 Функция автосохранения с понятным индикатором
    function triggerAutoSave() {
        if (!editor || !indicator) return;

        indicator.className = 'save-badge saving';
        saveText.textContent = 'Сохранение...';

        clearTimeout(saveTimeout);
        saveTimeout = setTimeout(() => {
            const docId = parseInt(editor.dataset.docId);
            const payload = {
                id: docId,
                title: titleInput.value,
                content: editor.innerHTML
            };

            fetch('/api/save-document', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            })
            .then(res => res.json())
            .then(data => {
                indicator.className = 'save-badge saved';
                saveText.textContent = `Сохранено в ${data.saved_at} ✨`;

                // Обновляем заголовок в боковом списке
                const activeItem = document.querySelector(`.doc-item[data-id="${docId}"] .doc-item-title`);
                if (activeItem) activeItem.textContent = titleInput.value;
            })
            .catch(() => {
                saveText.textContent = 'Ошибка сети!';
            });
        }, 700);
    }

    if (editor) editor.addEventListener('input', triggerAutoSave);
    if (titleInput) titleInput.addEventListener('input', triggerAutoSave);

    // 📚 Переключение документов в библиотеке
    function bindDocItems() {
        document.querySelectorAll('.doc-item').forEach(item => {
            item.onclick = () => {
                document.querySelectorAll('.doc-item').forEach(i => i.classList.remove('active'));
                item.classList.add('active');
                const id = item.dataset.id;

                fetch(`/api/document/${id}`)
                    .then(r => r.json())
                    .then(doc => {
                        editor.dataset.docId = doc.id;
                        titleInput.value = doc.title;
                        editor.innerHTML = doc.content;
                    });
            };
        });
    }
    bindDocItems();

    // Создание нового документа
    if (newDocBtn) {
        newDocBtn.addEventListener('click', () => {
            fetch('/api/save-document', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id: 99999,
                    title: 'Новый конспект',
                    content: 'Начните писать и выделять <span class="highlight-pen">главные мысли</span> маркером...'
                })
            })
            .then(r => r.json())
            .then(data => {
                const list = document.getElementById('doc-list');
                const div = document.createElement('div');
                div.className = 'doc-item card-3d-mini active';
                div.dataset.id = data.id;
                div.innerHTML = `
                    <div class="doc-meta">Новый документ • <span>Только что</span></div>
                    <h4 class="doc-item-title">Новый конспект</h4>
                `;
                document.querySelectorAll('.doc-item').forEach(i => i.classList.remove('active'));
                list.prepend(div);
                bindDocItems();
                div.click();
            });
        });
    }

    // Поиск по библиотеке
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const q = e.target.value.toLowerCase();
            document.querySelectorAll('.doc-item').forEach(item => {
                const title = item.querySelector('.doc-item-title').textContent.toLowerCase();
                item.style.display = title.includes(q) ? 'block' : 'none';
            });
        });
    }
});

// 👨‍🏫 Выставление оценки в кабинете учителя
function setGrade(subId, grade, btnEl) {
    fetch('/api/grade', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: subId, grade: grade })
    })
    .then(r => r.json())
    .then(data => {
        if (data.status === 'success') {
            const card = document.getElementById(`sub-${subId}`);
            card.querySelectorAll('.btn-grade').forEach(b => b.classList.remove('selected'));
            btnEl.classList.add('selected');

            const statusPill = document.getElementById(`status-${subId}`);
            statusPill.textContent = 'Проверено';
            statusPill.className = 'status-pill status-done';
        }
    });
}
