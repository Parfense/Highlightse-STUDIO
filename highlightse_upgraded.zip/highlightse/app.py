from flask import Flask, render_template, request, jsonify, redirect, url_for
from datetime import datetime

app = Flask(__name__)

# База документов для библиотеки
DOCUMENTS = [
    {
        "id": 1,
        "title": "Конспект по квантовой физике",
        "category": "Наука",
        "updated": "Сегодня, 14:20",
        "content": "Квантовая механика описывает природу на уровне атомов. <span class='highlight-pen'>Принцип неопределённости Гейзенберга</span> гласит, что невозможно одновременно точно измерить координату и импульс частицы. Выделите любой текст и нажмите на кнопку маркера выше!"
    },
    {
        "id": 2,
        "title": "Архитектура веб-приложений",
        "category": "IT & Разработка",
        "updated": "Вчера, 19:05",
        "content": "Современный фронтенд активно использует <span class='highlight-pen'>3D-трансформации и микроанимации</span> для улучшения пользовательского опыта (UX). Автосохранение позволяет не терять важные мысли в процессе работы."
    },
    {
        "id": 3,
        "title": "Эссе: Будущее образования",
        "category": "Литература",
        "updated": "12 мая",
        "content": "Интерактивные платформы объединяют учеников и преподавателей. Учитель сразу видит <span class='highlight-pen'>ключевые тезисы, выделенные маркером</span>, и может быстро оставить обратную связь."
    }
]

# Работы учеников для кабинета учителя
SUBMISSIONS = [
    {
        "id": 101,
        "student": "Алексей Смирнов",
        "avatar": "👨‍🎓",
        "title": "Лабораторная работа: Оптика",
        "submitted_at": "10 мин назад",
        "status": "На проверке",
        "grade": "",
        "excerpt": "При прохождении света через призму наблюдается <span class='highlight-pen'>дисперсия света — разложение в спектр</span> из-за разной скорости волн."
    },
    {
        "id": 102,
        "student": "Мария Иванова",
        "avatar": "👩‍🎓",
        "title": "Анализ романа «Мастер и Маргарита»",
        "submitted_at": "2 часа назад",
        "status": "Проверено",
        "grade": "5",
        "excerpt": "Булгаков использует приём «романа в романе», где <span class='highlight-pen'>тема совести и трусости</span> раскрывается через образ Понтия Пилата."
    },
    {
        "id": 103,
        "student": "Дмитрий Соколов",
        "avatar": "🧑‍💻",
        "title": "Алгоритмы сортировки на Python",
        "submitted_at": "Вчера",
        "status": "На проверке",
        "grade": "",
        "excerpt": "Быстрая сортировка (QuickSort) имеет среднюю сложность <span class='highlight-pen'>O(n log n)</span> и работает по принципу «разделяй и властвуй»."
    }
]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/main')
def main():
    return render_template('main.html', documents=DOCUMENTS, submissions=SUBMISSIONS)

@app.route('/api/document/<int:doc_id>', methods=['GET'])
def get_document(doc_id):
    doc = next((d for d in DOCUMENTS if d["id"] == doc_id), None)
    if doc:
        return jsonify(doc)
    return jsonify({"error": "Not found"}), 404

@app.route('/api/save-document', methods=['POST'])
def save_document():
    data = request.get_json()
    doc_id = data.get("id")
    content = data.get("content", "")
    title = data.get("title", "Без названия")

    for doc in DOCUMENTS:
        if doc["id"] == doc_id:
            doc["content"] = content
            doc["title"] = title
            doc["updated"] = "Только что"
            break
    else:
        new_id = max([d["id"] for d in DOCUMENTS] or [0]) + 1
        DOCUMENTS.append({
            "id": new_id,
            "title": title,
            "category": "Новый документ",
            "updated": "Только что",
            "content": content
        })
        doc_id = new_id

    return jsonify({
        "status": "success",
        "id": doc_id,
        "saved_at": datetime.now().strftime("%H:%M:%S")
    })

@app.route('/api/grade', methods=['POST'])
def grade_submission():
    data = request.get_json()
    sub_id = int(data.get("id"))
    grade = data.get("grade")
    for sub in SUBMISSIONS:
        if sub["id"] == sub_id:
            sub["grade"] = grade
            sub["status"] = "Проверено"
            return jsonify({"status": "success", "sub": sub})
    return jsonify({"status": "error"}), 404

if __name__ == '__main__':
    app.run(debug=True, port=5000)
